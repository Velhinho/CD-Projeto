{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": [
    "import matplotlib.pyplot as plt\n",
    "import matplotlib.colors as clrs\n",
    "\n",
    "from cycler import cycler\n",
    "\n",
    "plt.style.use('dslabs.mplstyle')\n",
    "\n",
    "my_palette = {'yellow': '#ECD474', 'pale orange': '#E9AE4E', 'salmon': '#E2A36B', 'orange': '#F79522', 'dark orange': '#D7725E',\n",
    "              'pale acqua': '#92C4AF', 'acqua': '#64B29E', 'marine': '#3D9EA9', 'green': '#10A48A', 'olive': '#99C244',\n",
    "              'pale blue': '#BDDDE0', 'blue2': '#199ED5', 'blue3': '#1DAFE5', 'dark blue': '#0C70B2',\n",
    "              'pale pink': '#D077AC', 'pink': '#EA4799', 'lavender': '#E09FD5', 'lilac': '#B081B9', 'purple': '#923E97',\n",
    "              'white': '#FFFFFF', 'light grey': '#D2D3D4', 'grey': '#939598', 'black': '#000000'}\n",
    "\n",
    "colors_pale = [my_palette['salmon'], my_palette['blue2'], my_palette['acqua']]\n",
    "colors_soft = [my_palette['dark orange'], my_palette['dark blue'], my_palette['green']]\n",
    "colors_live = [my_palette['orange'], my_palette['blue3'], my_palette['olive']]\n",
    "blues = [my_palette['pale blue'], my_palette['blue2'], my_palette['blue3'], my_palette['dark blue']]\n",
    "oranges = [my_palette['pale orange'], my_palette['salmon'], my_palette['orange'], my_palette['dark orange']]\n",
    "cmap_orange = clrs.LinearSegmentedColormap.from_list(\"myCMPOrange\", oranges)\n",
    "cmap_blues = clrs.LinearSegmentedColormap.from_list(\"myCMPBlues\", blues)\n",
    "\n",
    "LINE_COLOR = my_palette['dark blue']\n",
    "FILL_COLOR = my_palette['pale blue']\n",
    "DOT_COLOR = my_palette['blue3']\n",
    "ACTIVE_COLORS = [my_palette['pale blue'], my_palette['yellow'], my_palette['pale orange'],\n",
    "                 my_palette['acqua'], my_palette['pale pink'], my_palette['lavender']]\n",
    "\n",
    "alpha = 0.3\n",
    "plt.rcParams['axes.prop_cycle'] = cycler('color', ACTIVE_COLORS)\n",
    "\n",
    "plt.rcParams['text.color'] = LINE_COLOR\n",
    "plt.rcParams['patch.edgecolor'] = LINE_COLOR\n",
    "plt.rcParams['patch.facecolor'] = FILL_COLOR\n",
    "plt.rcParams['axes.facecolor'] = my_palette['white']\n",
    "plt.rcParams['axes.edgecolor'] = my_palette['grey']\n",
    "plt.rcParams['axes.labelcolor'] = my_palette['grey']\n",
    "plt.rcParams['xtick.color'] = my_palette['grey']\n",
    "plt.rcParams['ytick.color'] = my_palette['grey']\n",
    "\n",
    "plt.rcParams['grid.color'] = my_palette['light grey']\n",
    "\n",
    "plt.rcParams['boxplot.boxprops.color'] = FILL_COLOR\n",
    "plt.rcParams['boxplot.capprops.color'] = LINE_COLOR\n",
    "plt.rcParams['boxplot.flierprops.color'] = my_palette['pink']\n",
    "plt.rcParams['boxplot.flierprops.markeredgecolor'] = FILL_COLOR\n",
    "plt.rcParams['boxplot.flierprops.markerfacecolor'] = FILL_COLOR\n",
    "plt.rcParams['boxplot.whiskerprops.color'] = LINE_COLOR\n",
    "plt.rcParams['boxplot.meanprops.color'] = my_palette['purple']\n",
    "plt.rcParams['boxplot.meanprops.markeredgecolor'] = my_palette['purple']\n",
    "plt.rcParams['boxplot.meanprops.markerfacecolor'] = my_palette['purple']\n",
    "plt.rcParams['boxplot.medianprops.color'] = my_palette['green']"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.3"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
